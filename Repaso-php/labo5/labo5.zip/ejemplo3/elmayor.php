<!DOCTYPE html>
<html lang="es">
<head>
 <meta charset="utf-8" />
 <meta name="viewport" content="width=device-width,userscalable=no,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0"
/>
 <title>Trabajando con funciones de lista variable de
argumentos</title>
 <link rel="stylesheet"
href="http://fonts.googleapis.com/css?family=Oswald" />
 <link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstr
ap.min.css" rel="stylesheet" integrity="sha384-
EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
crossorigin="anonymous">
 <script src="js/modernizr.custom.lis.js"></script>
 <script src="js/prefixfree.min.js"></script>
</head>
<body>
    <section id="container">
<header >
<nav class="navbar navbar-dark bg-primary ">
<span class="navbar-text mx-auto"><h1>Mayor de una lista de
números</h1></span>
</nav>
</header>
<div class="container-fluid">
 <div class="row">
 <?php
 function elMayor(){
 $num_args = func_num_args();
 $args = func_get_args();
 $elmayor = $args[0];
 for($i=1; $i<$num_args; $i++){
 $elmayor = ($elmayor > $args[$i]) ? $elmayor :
func_get_arg($i);
 }
 return $elmayor;
 }
 echo "<div class='col-sm-6 py-5 px-lg-5 border bg-success'>El
mayor de 58, 167, 242, 85, 31, 109, -26, 81, 16, 126 es: " .
 "<h2>" . elMayor(58, 167, 242, 85, 31, 109, -26, 81, 16,
126) . "</h2></div>";
 ?>

<?php
 echo "<div class='col-sm-6 py-5 px-lg-5 border bgwarning'>El mayor de 61, 37, 75, 184, 42, -303, 43, 56, -121, 226,
172, 78, 6, 86 es:" .
 "<h2>" . elMayor(61, 37, 75, 184, 42, -303, 43, 56, -121,
226, 172, 78, 6, 86) . "</div>";
 ?>
 </div>
</div>
</section>
</body>
</html>
